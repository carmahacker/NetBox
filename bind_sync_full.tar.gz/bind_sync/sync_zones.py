#!/usr/bin/env python3
import paramiko
import os

# ===== НАСТРОЙКИ =====
SSH_HOST = "ns1.pharmasyntez.com"   # IP или hostname Debian (BIND)
SSH_USER = "bindreader"
SSH_KEY_PATH = "/opt/netbox/.ssh/id_rsa"
BIND_ZONES_PATH = "/etc/bind/"           # где лежат zone-файлы

LOCAL_SAVE_PATH = "/opt/bind_sync/zones" # локальная папка для копий
os.makedirs(LOCAL_SAVE_PATH, exist_ok=True)


def ssh_connect():
    """Подключение по SSH с ключом."""
    key = paramiko.RSAKey.from_private_key_file(SSH_KEY_PATH)

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        SSH_HOST,
        username=SSH_USER,
        pkey=key,
        timeout=10
    )
    return client


def read_zone_files(ssh):
    """Получение списка файлов зон и скачивание содержимого."""
    stdin, stdout, stderr = ssh.exec_command("ls -1 /etc/bind/*.zone /etc/bind/db.* 2>/dev/null")
    zone_files = stdout.read().decode().splitlines()

    zones_data = {}

    for zfile in zone_files:
        print(f"[+] Читаю {zfile}")
        sftp = ssh.open_sftp()

        remote_file = sftp.open(zfile, "r")
        content = remote_file.read().decode()
        remote_file.close()

        # сохраняем копию локально
        local_path = os.path.join(LOCAL_SAVE_PATH, os.path.basename(zfile))
        with open(local_path, "w") as f:
            f.write(content)

        zones_data[zfile] = content
        sftp.close()

    return zones_data


def main():
    ssh = ssh_connect()
    print("[✓] SSH подключение успешно")

    zones = read_zone_files(ssh)
    print(f"[✓] Получено файлов зон: {len(zones)}")

    ssh.close()


if __name__ == "__main__":
    main()
