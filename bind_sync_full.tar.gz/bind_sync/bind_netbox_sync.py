#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import print_function
import paramiko
from io import StringIO

import argparse
import os
import re
import shlex
import sys

import requests


# ====== Автозагрузка .env файла ======
def load_env_file(path=".env"):
    """
    Простейший парсер .env:
      KEY=value
      KEY="value"
      # комментарии игнорируются
    """
    if not os.path.exists(path):
        return
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                os.environ[key] = val
    except Exception as e:
        print("WARNING: не удалось загрузить .env: {}".format(e))


# Загружаем .env сразу при старте
load_env_file(".env")


# ======== Конфиг по умолчанию (можно переопределить аргументами) =========
# ===== SSH доступ к BIND =====
SSH_HOST = os.environ.get("SSH_HOST", "ns1.pharmasyntez.com")
SSH_USER = os.environ.get("SSH_USER", "bindreader")
SSH_KEY_PATH = os.environ.get("SSH_KEY_PATH", "/opt/netbox/.ssh/id_rsa")
SSH_ZONES_PATH = os.environ.get("SSH_ZONES_PATH", "/etc/bind/master")

DEFAULT_BIND_DIR = os.environ.get("ZONE_DIR", "/etc/bind/master")
DEFAULT_NETBOX_URL = os.environ.get("NETBOX_URL", "https://odinhub-spb.pharmasyntez.com")  # без /api на конце
DEFAULT_NETBOX_DNS_API_BASE = os.environ.get("NETBOX_DNS_API_BASE", "/api/plugins/netbox-dns")  # база для плагина
DEFAULT_CA_CERT = os.environ.get("CA_CERT")
DEFAULT_TIMEOUT = 10.0


# ====================== Утилиты для BIND парсера =========================
def ssh_connect():
    key = paramiko.RSAKey.from_private_key_file(SSH_KEY_PATH)

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        SSH_HOST,
        username=SSH_USER,
        pkey=key,
        timeout=10
    )
    return client

def ssh_fetch_zone_files():
    ssh = ssh_connect()

    cmd = f"ls -1 {SSH_ZONES_PATH}/db.* 2>/dev/null"
    stdin, stdout, stderr = ssh.exec_command(cmd)
    files = stdout.read().decode().splitlines()

    zones = []

    for path in files:
        zone_name = os.path.basename(path)[3:]   # db.example.com → example.com

        sftp = ssh.open_sftp()
        with sftp.open(path, "r") as fp:
            content = fp.read().decode()
        sftp.close()

        zones.append({
            "name": zone_name,
            "content": content
        })

        print(f"[SSH] Получен zone-file: {zone_name}")

    ssh.close()
    return zones


RR_TYPES = set([
    "A", "AAAA", "CNAME", "MX", "NS", "TXT", "SRV", "PTR",
    "CAA", "SPF"
])
def parse_zone_file_fp(fp, zone_name):
    zone = {
        "name": zone_name,
        "soa": None,
        "records": [],
        "nameservers": set(),
    }

    default_ttl = None
    prev_owner = "@"
    record_count = 0

    for is_commented, text in iter_logical_records(fp):
        active = not is_commented

        if text.startswith("$"):
            parts = text.split()
            if parts[0].upper() == "$TTL" and len(parts) >= 2:
                try:
                    default_ttl = int(parts[1])
                except:
                    pass
            continue

        try:
            tokens = shlex.split(text)
        except:
            continue

        if not tokens:
            continue

        rr = parse_rr_tokens(tokens, prev_owner, default_ttl)
        if rr is None:
            continue

        owner, rr_class, rr_type, ttl, rdata_tokens = rr
        prev_owner = owner

        if rr_type == "SOA":
            rt = [t for t in rdata_tokens if t not in ("(", ")")]
            if len(rt) >= 7:
                soa = {
                    "mname": normalize_fqdn(rt[0]),
                    "rname": rt[1],
                    "serial": int(rt[2]),
                    "refresh": int(rt[3]),
                    "retry": int(rt[4]),
                    "expire": int(rt[5]),
                    "minimum": int(rt[6]),
                    "ttl": ttl,
                }
                zone["soa"] = soa
            continue

        value = rdata_to_value(rr_type, rdata_tokens)
        if value is None:
            continue

        name_rel = normalize_name(owner, zone_name)

        record = {
            "name": name_rel,
            "type": rr_type,
            "value": value,
            "ttl": ttl,
            "active": active,
            "raw": text,
        }

        zone["records"].append(record)
        record_count += 1

        if rr_type == "NS" and value and active:
            ns_target = value.split()[0] if " " in value else value
            zone["nameservers"].add(normalize_fqdn(ns_target))

    print(f"    Parsed: {record_count} records")
    return zone



RR_CLASSES = set(["IN", "CH", "HS"])

def normalize_fqdn(name):
    """
    Нормализуем FQDN:
      - обрезаем пробелы
      - убираем завершающую точку
      - приводим к lower()
    """
    if not name:
        return ""
    name = name.strip()
    if name.endswith("."):
        name = name[:-1]
    return name.lower()


def strip_inline_comment(line):
    """
    Убирает комментарий '; ...' вне кавычек.
    """
    in_quote = False
    result = []
    for ch in line:
        if ch == '"':
            in_quote = not in_quote
            result.append(ch)
        elif ch == ';' and not in_quote:
            break
        else:
            result.append(ch)
    return "".join(result).rstrip()


def paren_delta(text):
    """
    Считает изменение глубины скобок () вне кавычек.
    """
    in_quote = False
    delta = 0
    for ch in text:
        if ch == '"':
            in_quote = not in_quote
        elif not in_quote:
            if ch == '(':
                delta += 1
            elif ch == ')':
                delta -= 1
    return delta


def iter_logical_records(fp):
    """
    Итерирует по логическим записям BIND (со склейкой многострочных),
    возвращая кортежи (is_commented, text).
    """
    buf = ""
    buf_commented = None
    depth = 0

    for raw in fp:
        line = raw.rstrip("\n")
        if not line.strip():
            # пустая строка — завершает текущий буфер, если он без скобок
            if buf and depth == 0:
                yield buf_commented, buf.strip()
                buf = ""
                buf_commented = None
            continue

        stripped = line.lstrip()
        is_commented = stripped.startswith(";")

        if is_commented:
            code = stripped[1:].lstrip()
        else:
            code = strip_inline_comment(stripped)

        if not code:
            # чистый комментарий
            if buf and depth == 0:
                yield buf_commented, buf.strip()
                buf = ""
                buf_commented = None
            continue

        if not buf:
            buf = code
            buf_commented = is_commented
            depth = paren_delta(code)
        else:
            # продолжение предыдущей записи
            buf += " " + code
            depth += paren_delta(code)

        if depth == 0 and buf:
            # логическая запись завершена
            yield buf_commented, buf.strip()
            buf = ""
            buf_commented = None

    # хвост
    if buf:
        yield buf_commented, buf.strip()


def parse_rr_tokens(tokens, prev_owner, default_ttl):
    """
    Разбирает токены записи BIND:
      [owner] [TTL] [CLASS] TYPE RDATA...

    Возвращает (owner, rr_class, rr_type, ttl, rdata_tokens)
    """
    if not tokens:
        return None

    idx = 0
    owner = None

    # Определяем owner: если первый токен выглядит как тип/TTL/CLASS,
    # значит owner унаследован.
    t0 = tokens[0].upper()
    if t0 in RR_TYPES or t0 in RR_CLASSES or t0.isdigit():
        owner = prev_owner
    else:
        owner = tokens[0]
        idx = 1

    ttl = None
    rr_class = None
    rr_type = None

    # Крутимся, пока не встретим тип
    while idx < len(tokens):
        t = tokens[idx]
        tu = t.upper()
        if tu in RR_TYPES:
            rr_type = tu
            idx += 1
            break
        elif tu in RR_CLASSES:
            rr_class = tu
            idx += 1
        elif t.isdigit():
            ttl = int(t)
            idx += 1
        else:
            # Неизвестно — предположим, что это тип
            rr_type = tu
            idx += 1
            break

    if rr_type is None:
        # Некорректная строка
        return None

    if rr_class is None:
        rr_class = "IN"

    if ttl is None:
        ttl = default_ttl

    rdata_tokens = tokens[idx:]

    return owner, rr_class, rr_type, ttl, rdata_tokens


def normalize_name(name, zone_name):
    """
    Приводит owner к относительному виду для NetBox:
      * '@' или пустой -> ''
      * FQDN зоны -> ''
      * относительные имена без точки оставляем как есть
      * FQDN внутри зоны -> усечённое
    """
    if name is None:
        return ""

    if name == "@":
        return ""

    # если без точки — относительное имя
    if "." not in name:
        return name

    # убираем завершающую точку
    if name.endswith("."):
        fqdn = name[:-1]
    else:
        fqdn = name

    if fqdn == zone_name:
        return ""

    if fqdn.endswith("." + zone_name):
        return fqdn[:-(len(zone_name) + 1)]

    # Вне зоны — пусть хранится как есть
    return fqdn

def rdata_to_value(rr_type, rdata_tokens):
    if not rdata_tokens:
        return ""

    # Снимаем круглые скобки для всех типов записей
    tokens = []
    in_parentheses = False
    paren_content = []

    for t in rdata_tokens:
        if t == "(" and not in_parentheses:
            in_parentheses = True
            continue
        elif t == ")" and in_parentheses:
            in_parentheses = False
            # Добавляем содержимое скобок как один токен
            if paren_content:
                tokens.append(" ".join(paren_content))
                paren_content = []
            continue

        if in_parentheses:
            paren_content.append(t)
        else:
            tokens.append(t)

    # Если осталось незакрытое содержимое скобок, добавляем его
    if paren_content:
        tokens.extend(paren_content)

    if rr_type in ("TXT", "SPF"):
        # Объединяем все токены
        value = " ".join(tokens)
        # Убираем внешние двойные кавычки если они есть
        if value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        # Убираем лишние пробелы
        value = " ".join(value.split())
        
        # Специальная обработка для DKIM записей с несбалансированными скобками
        if "DKIM1" in value:
            # Для DKIM записей убираем все скобки и лишние пробелы
            value = value.replace("(", "").replace(")", "")
            value = " ".join(value.split())
            
        return value

    if rr_type == "MX":
        # MX должен быть "<int> hostname"
        if len(tokens) < 2:
            return None

        pref, host = tokens[0], tokens[1]

        # проверяем, что preference — число
        if not pref.isdigit():
            return None

        # hostname может быть с точкой или без
        host = host.rstrip(".")
        if "." not in host:
            host = host + "."  # добавляем точку для относительных имен

        return pref + " " + host

    if rr_type == "SRV":
        # SRV: priority weight port target
        if len(tokens) < 4:
            return None
        priority, weight, port, target = tokens[0], tokens[1], tokens[2], tokens[3]
        if not (priority.isdigit() and weight.isdigit() and port.isdigit()):
            return None
        target = target.rstrip(".")
        if "." not in target:
            target = target + "."  # добавляем точку для относительных имен
        return "{0} {1} {2} {3}".format(priority, weight, port, target)

    if rr_type == "CAA":
        # CAA: flags tag value
        if len(tokens) < 3:
            return None
        flags, tag, value = tokens[0], tokens[1], " ".join(tokens[2:])
        value = value.strip('"')
        return "{0} {1} {2}".format(flags, tag, value)

    if rr_type == "PTR":
        # Для PTR записей значение должно быть полным FQDN
        if not tokens:
            return None
        value = tokens[0].rstrip(".")
        if "." not in value:
            # Если это относительное имя, добавляем точку
            value = value + "."
        else:
            # Если это FQDN, убеждаемся что есть завершающая точка
            if not value.endswith("."):
                value = value + "."
        return value

    if rr_type in ("NS", "CNAME"):
        # Для NS и CNAME записей значение должно быть полным FQDN
        if not tokens:
            return None
        value = tokens[0].rstrip(".")
        
        # Специальная обработка для @ (корень зоны)
        if value == "@":
            # Для корня зоны используем точку
            value = "."
        elif "." not in value:
            # Если это относительное имя, добавляем точку
            value = value + "."
        else:
            # Если это FQDN, убеждаемся что есть завершающая точка
            if not value.endswith("."):
                value = value + "."
        return value

    # Для всех остальных типов просто объединяем токены
    value = " ".join(tokens)
    # Убираем завершающую точку для A, AAAA записей
    if rr_type in ("A", "AAAA"):
        value = value.rstrip(".")
    return value


def parse_zone_file(path, zone_name):
    """
    Парсит один zone-file BIND в структуру:
    {
      'name': zone_name,
      'soa': { ... },
      'records': [ {name,type,value,ttl,active,raw}, ... ],
      'nameservers': set([...])
    }
    """
    zone = {
        "name": zone_name,
        "soa": None,
        "records": [],
        "nameservers": set(),
    }

    default_ttl = None
    prev_owner = "@"
    record_count = 0

    with open(path, "r") as fp:
        for is_commented, text in iter_logical_records(fp):
            # активность: закомментированная запись = inactive
            active = not is_commented

            if text.startswith("$"):
                # директивы
                parts = text.split()
                if parts[0].upper() == "$TTL" and len(parts) >= 2:
                    try:
                        default_ttl = int(parts[1])
                    except ValueError:
                        pass
                continue

            # shlex корректно разберёт и комментарии, и строки с кавычками
            try:
                tokens = shlex.split(text)
            except ValueError as e:
                print("    WARNING: не удалось разобрать строку '{0}': {1}".format(text, e))
                continue

            if not tokens:
                continue

            rr = parse_rr_tokens(tokens, prev_owner, default_ttl)
            if rr is None:
                continue

            owner, rr_class, rr_type, ttl, rdata_tokens = rr
            prev_owner = owner

            # УБРАЛИ фильтрацию закомментированных записей - теперь обрабатываем ВСЕ

            # --- Фильтр мусора (DNS SERVERS, INFO, и т.п.) ---
            if rr_type not in RR_TYPES and rr_type not in ("SOA", "NS"):
                continue

            if not rdata_tokens:
                continue

            # === SOA ===
            if rr_type == "SOA":
                rt = [t for t in rdata_tokens if t not in ("(", ")")]
                if len(rt) >= 7:
                    try:
                        soa = {
                            "mname": normalize_fqdn(rt[0]),
                            "rname": rt[1],
                            "serial": int(rt[2]),
                            "refresh": int(rt[3]),
                            "retry": int(rt[4]),
                            "expire": int(rt[5]),
                            "minimum": int(rt[6]),
                            "ttl": ttl,
                        }
                        zone["soa"] = soa
                    except ValueError:
                        pass
                continue

            # === Все остальные записи ===
            value = rdata_to_value(rr_type, rdata_tokens)
            # Если парсер вернул None → мусорную запись пропускаем
            if value is None:
                continue

            name_rel = normalize_name(owner, zone_name)

            record = {
                "name": name_rel,
                "type": rr_type,
                "value": value,
                "ttl": ttl,
                "active": active,  # active будет False для закомментированных записей
                "raw": text,
            }

            # Проверяем проблемные значения
            if rr_type == "TXT" and ("(" in value or ")" in value):
                if value.count("(") != value.count(")"):
                    print("    WARNING: Несбалансированные скобки в TXT записи: {0}".format(value))

            zone["records"].append(record)
            record_count += 1

            # === NS запись → добавляем в список nameservers ===
            if rr_type == "NS" and value and active:  # Только активные NS добавляем в список nameservers
                # Для NS записей value может содержать только имя сервера
                ns_target = value.split()[0] if " " in value else value
                zone["nameservers"].add(normalize_fqdn(ns_target))

    print("    Обработано записей (активных+неактивных): {0}".format(record_count))
    return zone

def load_bind_zones(bind_dir):
    """
    Грубо: берём все файлы вида db.* в каталоге и считаем,
    что зона = часть после 'db.'.

    При необходимости можно заменить на явный список.
    """
    if not bind_dir:
        raise RuntimeError("bind_dir пустой. Проверь ZONE_DIR или параметр --bind-dir")
    if not os.path.isdir(bind_dir):
        raise RuntimeError("Каталог с зонами не найден: {0}".format(bind_dir))

    zones = []
    for fname in os.listdir(bind_dir):
        if not fname.startswith("db."):
            continue
        zone_name = fname[3:]
        path = os.path.join(bind_dir, fname)
        if not os.path.isfile(path):
            continue
        print("  Парсим зону: {0}".format(zone_name))
        zone = parse_zone_file(path, zone_name)
        
        # Подсчитываем активные и неактивные записи
        active_count = sum(1 for r in zone["records"] if r["active"])
        inactive_count = len(zone["records"]) - active_count
        
        print("    Найдено записей: {0} (активных: {1}, неактивных: {2})".format(
            len(zone["records"]), active_count, inactive_count))
        print("    Найдено NS: {0}".format(len(zone["nameservers"])))
        if zone["soa"]:
            print("    SOA: {0}".format(zone["soa"]["mname"]))
        zones.append(zone)
    return zones
# ========================== Клиент NetBox DNS =============================

class NetBoxClient(object):
    def __init__(self, url, token, api_base, timeout, ca_cert=None):
        self.base = url.rstrip("/")
        self.api_base = api_base.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": "Token {0}".format(token),
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        # Проверка TLS
        if ca_cert:
            self.session.verify = ca_cert
        else:
            self.session.verify = False
    def list_valid_zone_ids(self):
        schema = self._request("GET", "/records/schema/")
        enum = schema["properties"]["zone"]["enum"]
        return {name: zid for zid, name in enum}


    def _url(self, path):
        if not path.startswith("/"):
            path = "/" + path
        return self.base + self.api_base + path

    def _request(self, method, path, **kwargs):
        url = self._url(path)
        resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        if resp.status_code >= 400:
            raise RuntimeError(
                "HTTP {0} {1}: {2}".format(resp.status_code, url, resp.text)
            )
        return resp.json() if resp.text else None

    # ---- Nameservers ----

    def list_nameservers(self):
        # limit=0 -> все объекты
        return self._request("GET", "/nameservers/?limit=0")["results"]

    def create_nameserver(self, name):
        payload = {"name": name}
        return self._request("POST", "/nameservers/", json=payload)

    def delete_nameserver(self, ns_id):
        self._request("DELETE", "/nameservers/{0}/".format(ns_id))

    # ---- Zones ----

    def list_zones(self):
        return self._request("GET", "/zones/?limit=0")["results"]

    def find_zone_by_name(self, name):
        res = self._request("GET", "/zones/?name={0}".format(name))
        if res["count"]:
            return res["results"][0]
        return None

    def create_zone(self, name, status, nameserver_ids, soa, view_id=None, soa_mname_id=None):
        payload = {
            "name": name,
            "status": status,
            "nameservers": nameserver_ids,
            "soa_mname": soa_mname_id,
            "soa_rname": soa.get("rname"),
            "soa_ttl": soa.get("ttl"),
            "soa_refresh": soa.get("refresh"),
            "soa_retry": soa.get("retry"),
            "soa_expire": soa.get("expire"),
            "soa_minimum": soa.get("minimum"),
        }
        if view_id is not None:
            payload["view"] = view_id
        return self._request("POST", "/zones/", json=payload)

    def update_zone(self, zone_id, nameserver_ids, soa, soa_mname_id=None):
        payload = {
            "nameservers": nameserver_ids,
            "soa_mname": soa_mname_id,
            "soa_rname": soa.get("rname"),
            "soa_ttl": soa.get("ttl"),
            "soa_refresh": soa.get("refresh"),
            "soa_retry": soa.get("retry"),
            "soa_expire": soa.get("expire"),
            "soa_minimum": soa.get("minimum"),
        }
        return self._request("PATCH", "/zones/{0}/".format(zone_id), json=payload)

    # ---- Records ----

    def list_records_for_zone(self, zone_name):
        return self._request(
            "GET", "/records/?zone={0}&limit=0".format(zone_name)
        )["results"]


    def create_record(self, zone_id, rec):

        # NetBox DNS не принимает пустой name — используем "@"
        name = rec["name"] or "@"
        payload = {
            "zone": zone_id,
            "type": rec["type"],
            "name": name,
            "value": rec["value"],
            "ttl": rec["ttl"],
            "status": "active" if rec.get("active", True) else "inactive",
        }
        return self._request("POST", "/records/", json=payload)

    def update_record(self, rec_id, rec):
        name = rec.get("name") or "@"
        payload = {
            "ttl": rec["ttl"],
            "value": rec["value"],
            "status": "active" if rec.get("active", True) else "inactive",
        }
        return self._request("PATCH", "/records/{0}/".format(rec_id), json=payload)

    def delete_record(self, rec_id):
        self._request("DELETE", "/records/{0}/".format(rec_id))


# ======================= Логика сравнения и синка =========================

def key_for_record(rec):
    rtype = (rec.get("type") or "").upper()
    name = rec.get("name") or "@"
    value = rec.get("value") or ""

    # нормализация TXT/SPF
    if rtype in ("TXT", "SPF"):
        value = value.rstrip(".").strip()
        value = " ".join(value.split())

    # MX – удаляем точку
    if rtype == "MX":
        value = value.rstrip(".")

    return (rtype, name, value)

def netbox_record_to_internal(rec):
    rtype = (rec.get("type") or "").upper()
    val = rec.get("value") or ""

    if rtype in ("TXT", "SPF"):
        # удаляем финальную точку
        if val.endswith("."):
            val = val[:-1]
        # убираем двойные пробелы
        val = " ".join(val.split())

    if rtype == "MX":
        if val.endswith("."):
            val = val[:-1]

    return {
        "id": rec.get("id"),
        "zone": rec.get("zone", {}).get("id") or rec.get("zone"),
        "type": rtype,
        "name": rec.get("name") or "",
        "value": val,
        "ttl": rec.get("ttl"),
        "status": rec.get("status"),
        "active": rec.get("active"),
        "managed": rec.get("managed"),
    }


def diff_nameservers(bind_zones, nb_client, dry_run):
    """
    Сравнение и синхронизация Nameserver'ов.
    Логика:
      * Добавляем NS, которых нет в NetBox.
      * Удаляем NS, только если они:
         - не встречаются в BIND,
         - и не используются ни одной зоной.
    """
    # NS из BIND уже нормализованы
    bind_ns = set()
    for z in bind_zones:
        bind_ns.update(z["nameservers"])

    # NS из NetBox
    nb_ns_list = nb_client.list_nameservers()
    nb_ns_by_name = {}
    for ns in nb_ns_list:
        norm = normalize_fqdn(ns["name"])
        nb_ns_by_name[norm] = ns

    # Что нужно создать
    to_create = sorted(bind_ns - set(nb_ns_by_name.keys()))

    # Сначала получаем список всех зон, чтобы проверить зависимости
    nb_zones = nb_client.list_zones()

    # Выясняем зависимые NS - те, которые используются зонами
    referenced_ns = set()
    for zone in nb_zones:
        for ns_obj in zone.get("nameservers", []):
            # нормализуем имя
            norm = normalize_fqdn(ns_obj["name"])
            referenced_ns.add(norm)

    # Теперь определяем какие NS можно удалять
    to_delete = []
    for norm, ns in nb_ns_by_name.items():
        if norm not in bind_ns and norm not in referenced_ns:
            to_delete.append(ns)
        elif norm not in bind_ns and norm in referenced_ns:
            print("[NS][SKIP-IN-USE] {} (id={}) — still used by zones".format(
                ns["name"], ns["id"]
            ))

    # --- ADD ---
    for name in to_create:
        print("[NS][ADD] {0}".format(name))
        if not dry_run:
            nb_client.create_nameserver(name)

    # --- DELETE (только свободные) ---
    for ns in to_delete:
        print("[NS][DEL] {0} (id={1})".format(ns["name"], ns["id"]))
        if not dry_run:
            try:
                nb_client.delete_nameserver(ns["id"])
            except RuntimeError as e:
                if "HTTP 409" in str(e):
                    print("[NS][WARN] Не удалось удалить {} (id={}): всё ещё используется зоной".format(
                        ns["name"], ns["id"]
                    ))
                else:
                    raise

    # перечитываем
    nb_ns_list = nb_client.list_nameservers()
    nb_ns_by_name = {}
    for ns in nb_ns_list:
        norm = normalize_fqdn(ns["name"])
        nb_ns_by_name[norm] = ns

    return nb_ns_by_name

def sync_zones(bind_zones, nb_client, nb_ns_by_name, default_zone_status,
               view_id, dry_run):
    """
    Создание/обновление зон и привязка NS / SOA полей.
    Возвращает словарь zone_name -> NetBox zone object.
    """
    nb_zones = nb_client.list_zones()
    nb_zones_by_name = {}
    for z in nb_zones:
        nb_zones_by_name[z["name"]] = z

    result = {}

    for bz in bind_zones:
        name = bz["name"]
        soa = bz["soa"]
        if soa is None:
            print("[ZONE][WARN] {0}: нет SOA, пропускаю".format(name))
            continue

        # список NS для зоны по данным BIND (уже нормализованные имена)
        ns_targets = sorted(bz["nameservers"])
        ns_ids = []
        for ns in ns_targets:
            ns_obj = nb_ns_by_name.get(ns)
            if not ns_obj:
                print("[ZONE][WARN] {0}: nameserver {1} не найден в NetBox".format(
                    name, ns
                ))
                continue
            ns_ids.append(ns_obj["id"])

        # SOA mname -> ID из списка NS (если найдём)
        mname = soa.get("mname")
        soa_mname_id = None
        if mname:
            ns_obj = nb_ns_by_name.get(mname)
            if ns_obj:
                soa_mname_id = ns_obj["id"]
            else:
                print("[ZONE][WARN] {0}: SOA mname {1} не найден среди Nameservers, "
                      "передаю soa_mname = null".format(name, mname))

        existing = nb_zones_by_name.get(name)
        if existing is None:
            print("[ZONE][ADD] {0}".format(name))

            if not dry_run:
                # создаём
                nb_client.create_zone(
                    name=name,
                    status=default_zone_status,
                    nameserver_ids=ns_ids,
                    soa=soa,
                    soa_mname_id=soa_mname_id,
                    view_id=view_id,
                )

                # перечитываем корректный zone_id
                created = nb_client.find_zone_by_name(name)
                if not created:
                    raise RuntimeError("Не удалось перечитать созданную зону: {}".format(name))

                result[name] = created

            else:
                fake = {"id": -1, "name": name}
                result[name] = fake

        else:
            print("[ZONE][UPDATE] {0}".format(name))

            if not dry_run:
                nb_client.update_zone(
                    existing["id"],
                    ns_ids,
                    soa,
                    soa_mname_id=soa_mname_id,
                )

                updated = nb_client.find_zone_by_name(name)
                if not updated:
                    raise RuntimeError("Не удалось перечитать зону после обновления: {}".format(name))

                result[name] = updated

            else:
                result[name] = existing

    return result

def sync_records_for_zone(bind_zone, nb_zone, nb_client, dry_run):
    """
    Сравнение и синхронизация записей конкретной зоны:
    - добавляем недостающие (активные и неактивные);
    - обновляем TTL / status;
    - удаляем записи, которых нет в BIND;
    - игнорируем managed, SOA, NS;
    - выравниваем TTL у записей с одинаковым owner и типом (NetBox ограничение).
    """

    zone_id = nb_zone["id"]
    zone_name = bind_zone["name"]

    # --- BIND: отбираем записи, кроме SOA / NS ---
    bind_recs = []
    for r in bind_zone["records"]:
        if r["type"] in ("SOA", "NS"):
            continue
        bind_recs.append(r)

    # === ВАЖНО ===
    # Выравниваем TTL у всех записей с одинаковым owner и типом.
    # NetBox запрещает разные TTL для записей с одинаковым name и типом.
    records_by_name_type = {}
    for r in bind_recs:
        name = r["name"] or "@"
        rtype = r["type"]
        key = (name, rtype)
        records_by_name_type.setdefault(key, []).append(r)

    # Нормализуем TTL для каждой группы записей с одинаковым name и типом
    for key, items in records_by_name_type.items():
        if len(items) > 1:
            # Берем TTL из первой записи в группе
            ttl_ref = items[0]["ttl"]
            for rr in items:
                rr["ttl"] = ttl_ref

    # Словарь ключей из BIND
    bind_by_key = {}
    for r in bind_recs:
        bind_by_key[key_for_record(r)] = r

    # --- NetBox: получаем записи этой зоны ---
    nb_raw = nb_client.list_records_for_zone(zone_name)
    nb_internal = [netbox_record_to_internal(x) for x in nb_raw]

    nb_by_key = {}
    for r in nb_internal:
        nb_by_key[key_for_record(r)] = r

    # --- Проверяем конфликты имен перед добавлением ---
    existing_names_by_type = {}
    for nb_r in nb_internal:
        name = nb_r["name"] or "@"
        rtype = nb_r["type"]
        if name not in existing_names_by_type:
            existing_names_by_type[name] = set()
        existing_names_by_type[name].add(rtype)

    # --- ДОБАВЛЕНИЕ ---
    for k, r in bind_by_key.items():
        if k not in nb_by_key:
            # --- 1. ГРУБЫЙ ФИЛЬТР МУСОРА (DNS SERVERS, DNS RECORDS) ---
            if r["name"].upper() == "DNS":
                print("[RR][SKIP-GARBAGE] zone={} name={} type={} value={} — DNS header garbage".format(
                    zone_name, r["name"], r["type"], r["value"]
                ))
                continue

            if r["type"] == "PTR":
                garbage_values = {"records.", "record.", "names.", "servers.", "entries."}
                if r["value"].lower() in garbage_values:
                    print("[RR][SKIP-GARBAGE] zone={} name={} type={} value={} — garbage PTR".format(
                        zone_name, r["name"], r["type"], r["value"]
                    ))
                    continue

                if r["value"].endswith(".") and r["value"].count(".") == 1:
                    print("[RR][SKIP-GARBAGE] zone={} name={} type={} value={} — invalid PTR target".format(
                        zone_name, r["name"], r["type"], r["value"]
                    ))
                    continue

            # --- 2. ОТБРАСЫВАЕМ НЕ-валидные DNS типы ---
            VALID_RR_TYPES = {
                "A", "AAAA", "CNAME", "MX", "NS",
                "SOA", "TXT", "SPF", "PTR", "SRV", "CAA"
            }
            if r["type"] not in VALID_RR_TYPES:
                print("[RR][SKIP-NON-RFC] zone={} name={} type={} — invalid DNS RR type".format(
                    zone_name, r["name"], r["type"]
                ))
                continue

            # --- 3. ПУСТЫЕ ЗНАЧЕНИЯ ОТБРАСЫВАЕМ ---
            if not r["value"] or r["value"].strip() == "":
                print("[RR][SKIP-EMPTY] zone={} name={} type={} — empty value".format(
                    zone_name, r["name"], r["type"]
                ))
                continue


            status = "active" if r["active"] else "inactive"
            name = r["name"] or "@"
            rtype = r["type"]
            
            # Проверяем конфликты CNAME
            if rtype == "CNAME":
                conflicting_types = existing_names_by_type.get(name, set())
                if conflicting_types and "CNAME" not in conflicting_types:
                    print("[RR][CONFLICT] zone={0} name={1}: CNAME не может сосуществовать с {2}".format(
                        zone_name, name, ", ".join(conflicting_types)
                    ))
                    # Пропускаем создание CNAME если есть конфликтующие записи
                    continue
            
            # Проверяем конфликты других типов с существующим CNAME
            existing_types = existing_names_by_type.get(name, set())
            if "CNAME" in existing_types and rtype != "CNAME":
                print("[RR][CONFLICT] zone={0} name={1}: {2} не может сосуществовать с CNAME".format(
                    zone_name, name, rtype
                ))
                # Пропускаем создание записи если уже есть CNAME
                continue

            print("[RR][ADD] zone={0} name={1} type={2} value={3} status={4} ttl={5}".format(
                zone_name, r["name"], r["type"], r["value"], status, r["ttl"]
            ))
            if not dry_run:
                try:
                    nb_client.create_record(zone_id, r)
                    # Обновляем кэш существующих записей
                    if name not in existing_names_by_type:
                        existing_names_by_type[name] = set()
                    existing_names_by_type[name].add(rtype)
                except RuntimeError as e:
                    error_msg = str(e)
                    if "CNAME is not allowed" in error_msg or "is not allowed" in error_msg:
                        print("[RR][CONFLICT] Конфликт записей: {0}".format(error_msg))
                        print("[RR][SKIP] Пропускаем создание записи из-за конфликта")
                        continue
                    
                    elif "is not a valid DNS domain name" in error_msg or "is not a valid fully qualified DNS host name" in error_msg:
                        print("[RR][WARN] Проблема с форматом DNS имени: {0}".format(error_msg))
                        print("[RR][WARN] Попытка исправления значения...")
                        
                        # Исправляем проблемные значения
                        cleaned_value = r["value"]
                        
                        # Убираем экранированные символы
                        cleaned_value = cleaned_value.replace("\\", "")
                        
                        # Исправляем @.
                        if cleaned_value == "@.":
                            cleaned_value = "."
                        
                        # Для CNAME, NS, PTR записей убеждаемся в корректном формате
                        if r["type"] in ("CNAME", "NS", "PTR"):
                            cleaned_value = cleaned_value.rstrip(".")
                            if cleaned_value == "@":
                                cleaned_value = "."
                            elif "." not in cleaned_value:
                                cleaned_value = cleaned_value + "."
                            else:
                                if not cleaned_value.endswith("."):
                                    cleaned_value = cleaned_value + "."
                        
                        r["value"] = cleaned_value
                        
                        try:
                            nb_client.create_record(zone_id, r)
                            if name not in existing_names_by_type:
                                existing_names_by_type[name] = set()
                            existing_names_by_type[name].add(rtype)
                            print("[RR][ADD-RETRY] zone={0} name={1} type={2} value={3}".format(
                                zone_name, r['name'], r['type'], r['value']
                            ))
                        except RuntimeError as e2:
                            print("[RR][ERROR] Не удалось создать запись после исправления DNS имени: {0}".format(e2))
                            # Пропускаем проблемную запись
                    
                    elif "unbalanced parentheses" in error_msg or "is not a valid value" in error_msg:
                        print("[RR][WARN] Проблема с форматом значения: {0}".format(error_msg))
                        print("[RR][WARN] Попытка очистки значения...")
                        # Очищаем проблемное значение
                        if r["type"] == "TXT":
                            # Для TXT убираем проблемные символы
                            cleaned_value = r["value"]
                            # Убираем все скобки для TXT записей
                            cleaned_value = cleaned_value.replace("(", "").replace(")", "")
                            # Убираем лишние пробелы
                            cleaned_value = " ".join(cleaned_value.split())
                            r["value"] = cleaned_value
                            try:
                                nb_client.create_record(zone_id, r)
                                if name not in existing_names_by_type:
                                    existing_names_by_type[name] = set()
                                existing_names_by_type[name].add(rtype)
                                print("[RR][ADD-RETRY] zone={0} name={1} type={2} value={3}".format(
                                    zone_name, r['name'], r['type'], r['value']
                                ))
                            except RuntimeError as e2:
                                print("[RR][ERROR] Не удалось создать запись после очистки: {0}".format(e2))
                                # Пропускаем проблемную запись
                    
                    elif "TTL is different" in error_msg:
                        print("[RR][WARN] Конфликт TTL: {0}".format(error_msg))
                        print("[RR][WARN] Попытка использования TTL из существующей записи...")
                        
                        # Находим существующие записи с таким же именем и типом
                        conflict_name = r["name"] or "@"
                        conflict_type = r["type"]
                        existing_ttl = None
                        
                        # Ищем TTL из существующих записей NetBox
                        for nb_rec in nb_internal:
                            if (nb_rec["name"] or "@") == conflict_name and nb_rec["type"] == conflict_type:
                                existing_ttl = nb_rec["ttl"]
                                break
                        
                        if existing_ttl is not None:
                            # Используем TTL из существующей записи
                            r["ttl"] = existing_ttl
                            try:
                                nb_client.create_record(zone_id, r)
                                if name not in existing_names_by_type:
                                    existing_names_by_type[name] = set()
                                existing_names_by_type[name].add(rtype)
                                print("[RR][ADD-RETRY] zone={0} name={1} type={2} value={3} ttl={4} (использован TTL из существующей записи)".format(
                                    zone_name, r['name'], r['type'], r['value'], r['ttl']
                                ))
                            except RuntimeError as e2:
                                print("[RR][ERROR] Не удалось создать запись после изменения TTL: {0}".format(e2))
                                # Пропускаем проблемную запись
                        else:
                            print("[RR][ERROR] Не удалось найти существующий TTL для разрешения конфликта")
                            # Пропускаем проблемную запись
                    
                    else:
                        raise

    # --- ОБНОВЛЕНИЕ ---
    for k, nb_r in nb_by_key.items():
        bind_r = bind_by_key.get(k)
        if not bind_r:
            continue

        need_update = False
        new_ttl = bind_r["ttl"]
        new_status = "active" if bind_r["active"] else "inactive"

        if nb_r["ttl"] != new_ttl:
            need_update = True

        if nb_r.get("status") is not None and nb_r["status"] != new_status:
            need_update = True

        if need_update:
            old_status = nb_r.get("status", "unknown")
            print("[RR][UPDATE] zone={0} name={1} type={2} value={3} ttl {4} -> {5}, status {6} -> {7}".format(
                zone_name, bind_r["name"], bind_r["type"], bind_r["value"],  # ИСПРАВЛЕНО: bind_b -> bind_r
                nb_r["ttl"], new_ttl, old_status, new_status
            ))
            if not dry_run:
                nb_client.update_record(nb_r["id"], bind_r)

    # --- УДАЛЕНИЕ ---
    for k, nb_r in nb_by_key.items():
        if k in bind_by_key:
            continue

        # NetBox запрещает удалять managed / NS / SOA
        if nb_r.get("managed") or nb_r.get("type") in ("SOA", "NS"):
            print("[RR][SKIP-MANAGED] zone={0} name={1} type={2} value={3}".format(
                zone_name, nb_r["name"], nb_r["type"], nb_r["value"]
            ))
            continue

        print("[RR][DEL] zone={0} name={1} type={2} value={3}".format(
            zone_name, nb_r["name"], nb_r["type"], nb_r["value"]
        ))

        if not dry_run:
            nb_client.delete_record(nb_r["id"])

# =============================== main =====================================

def main():
    parser = argparse.ArgumentParser(
        description="Синхронизация BIND zone файлов в NetBox DNS (BIND -> NetBox)"
    )
    parser.add_argument(
        "--bind-dir", default=DEFAULT_BIND_DIR,
        help="Каталог с db.* файлами зон BIND (по умолчанию {0})".format(
            DEFAULT_BIND_DIR
        ),
    )
    parser.add_argument(
        "--netbox-url", default=DEFAULT_NETBOX_URL,
        help="Базовый URL NetBox (например https://netbox.example.com)",
    )
    parser.add_argument(
        "--netbox-token", default=os.environ.get("NETBOX_TOKEN"),
        help="API token NetBox (по умолчанию из переменной окружения NETBOX_TOKEN)",
    )
    parser.add_argument(
        "--netbox-dns-api-base", default=DEFAULT_NETBOX_DNS_API_BASE,
        help="Базовый путь API плагина (по умолчанию /api/plugins/netbox-dns)",
    )
    parser.add_argument(
        "--view-id", type=int, default=None,
        help="ID DNS View для создаваемых зон (если требуется)",
    )
    parser.add_argument(
        "--zone-status", default="active",
        help="status для создаваемых зон (active/reserved/deprecated/parked)",
    )
    parser.add_argument(
        "--apply", action="store_true",
        help="По умолчанию только показывает план. С --apply делает изменения.",
    )
    parser.add_argument(
        "--ca-cert",
        help="Путь к CA сертификату для проверки TLS (например /opt/bind_sync/certs/fullchain.pem)",
        default=DEFAULT_CA_CERT,
    )
    parser.add_argument(
        "--secret-key",
        help="Секретный ключ, разрешающий внесение изменений в NetBox. "
             "Можно также задать через переменную окружения SYNC_SECRET_KEY.",
        default=os.environ.get("SYNC_SECRET_KEY"),
    )

    args = parser.parse_args()

    if not args.netbox_token:
        print("Ошибка: не указан токен NetBox (--netbox-token или NETBOX_TOKEN)",
              file=sys.stderr)
        return 1

    print("=== Параметры ===")
    print("  bind-dir      :", args.bind_dir)
    print("  netbox-url    :", args.netbox_url)
    print("  api-base      :", args.netbox_dns_api_base)
    print("  ca-cert       :", args.ca_cert or "(system default)")


    print("=== Чтение зон из BIND: {0}".format(args.bind_dir))
#    bind_zones = load_bind_zones(args.bind_dir)
    print("=== Получение зон по SSH с BIND ===")
    zone_files = ssh_fetch_zone_files()

    bind_zones = []

    for zf in zone_files:
        zone_name = zf["name"]
        text = zf["content"]

    # Используем старый парсер, но читаем из StringIO (файл в памяти)
        fp = StringIO(text)
        zone = parse_zone_file_fp(fp, zone_name)
        bind_zones.append(zone)

        for z in bind_zones:
            print("  зона: {0}, записей: {1}, NS: {2}".format(
                z["name"], len(z["records"]), len(z["nameservers"])
            ))

    # Проверяем секретный ключ для APPLY режима ДО реальных изменений
    if args.apply:
        expected_key = os.environ.get("SYNC_SECRET_KEY")
        provided_key = args.secret_key

        if not expected_key:
            print("ОШИБКА: в окружении не задан SYNC_SECRET_KEY, "
                  "поэтому APPLY запрещён.", file=sys.stderr)
            return 1

        if not provided_key:
            print("ОШИБКА: не указан --secret-key, но режим APPLY активирован.",
                  file=sys.stderr)
            return 1

        if provided_key != expected_key:
            print("ОШИБКА: неверный секретный ключ — APPLY запрещён.",
                  file=sys.stderr)
            return 1

    nb = NetBoxClient(
        url=args.netbox_url,
        token=args.netbox_token,
        api_base=args.netbox_dns_api_base,
        timeout=DEFAULT_TIMEOUT,
        ca_cert=args.ca_cert,
    )

    dry_run = not args.apply
    if dry_run:
        print("=== РЕЖИМ DRY-RUN (ничего не меняем, только показываем план) ===")
    else:
        print("=== РЕЖИМ APPLY (будут изменения в NetBox!) ===")

    # В функции main, после синхронизации nameserver'ов
    print("=== Синхронизация Nameserver'ов ===")
    nb_ns_by_name = diff_nameservers(bind_zones, nb, dry_run)

    # Проверяем, что все необходимые NS существуют перед синхронизацией зон
    for bz in bind_zones:
        for ns_name in bz["nameservers"]:
            if ns_name not in nb_ns_by_name:
                print("[WARN] Зона '{}' требует NS '{}', но он отсутствует в NetBox".format(
                    bz["name"], ns_name
                ))

    print("=== Синхронизация зон (SOA / NS) ===")
    nb_zones_by_name = sync_zones(
        bind_zones,
        nb,
        nb_ns_by_name,
        default_zone_status=args.zone_status,
        view_id=args.view_id,
        dry_run=dry_run,
    )

    print("=== Синхронизация записей по зонам ===")

    if dry_run:
        print("DRY-RUN: пропускаю синхронизацию записей (требуются реальные zone_id)")
    else:
        for bz in bind_zones:
            nb_zone = nb_zones_by_name.get(bz["name"])
            if not nb_zone:
                print("[ZONE][SKIP] {0}: зоны нет в NetBox и мы её не создали".format(
                    bz["name"]
                ))
                continue
            sync_records_for_zone(bz, nb_zone, nb, dry_run)

    print("Готово.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

